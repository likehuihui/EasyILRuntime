@interface BundleId : NSObject
+(NSString *)getIPv6 : (const char *)host;
@end