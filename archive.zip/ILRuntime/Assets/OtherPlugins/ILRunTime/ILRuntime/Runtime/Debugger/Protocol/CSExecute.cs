﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ILRuntime.Runtime.Debugger.Protocol
{
    public class CSExecute
    {
        public int ThreadHashCode { get; set; }
    }
}
