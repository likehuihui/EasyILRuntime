﻿using System;
using System.Collections.Generic;
using System.Text;


namespace GOLDS
{
    /// <summary>
    /// 金鲨银鲨逻辑接口
    /// </summary>
    public partial class GOLDS_
    {

    }
}
