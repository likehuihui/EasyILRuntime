﻿/*
 *    日期:
 *    作者:
 *    标题:
 *    功能:
*/
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
namespace RunTimeFrame
{
    public class Platform
    {
        public static void Main()
        {
            Preload pre = new Preload();
            Button btn = GameObject.Find("Button").GetComponent<Button>();
            btn.onClick.AddListener(OnClick);

            //Debug.Log("bbb");
        }
        public static void OnClick()
        {

            Debug.Log("点击1");
            SceneManager.LoadScene("GameScene");
            //Application.LoadLevel(1);
        }
    }
}