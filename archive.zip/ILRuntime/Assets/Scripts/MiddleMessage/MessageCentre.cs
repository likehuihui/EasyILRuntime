﻿/*
 *    日期:
 *    作者:
 *    标题:
 *    功能:
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Middle
{
    /// <summary>
    /// 发送消息
    /// </summary>
    public class MessageCentre 
    {
        /// <summary>
        /// 进入场景
        /// </summary>
        public static Action<string> enterGameScene;
    }
}