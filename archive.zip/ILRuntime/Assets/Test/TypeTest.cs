﻿/*
 *    日期:
 *    作者:
 *    标题:
 *    功能:
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace RunTimeFrame
{
   public class TypeTest  
   {
        public void Call1()
        {
            Debug.Log("call 1");
        }
        public static void Call2()
        {
            Debug.Log("call 2");
        }
   }
}