﻿using UnityEngine;

namespace RunTimeFrame
{
    public class Platform
    {
        public static void Main()
        {
            Debug.Log("我是DLL");
        }
    }
}
